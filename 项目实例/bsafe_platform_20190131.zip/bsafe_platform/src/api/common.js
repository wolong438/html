import { axios } from '@/utils/request'

/** 共用的api */
const api = {
  uploadImage: '/system/upload/uploadResources.do'
}

export default api

export function uploadImage (param) {
  return new Promise((resove, reject) => {
    axios({
      url: '/system/upload/uploadResources.do',
      method: 'post',
      data: param
    }).then(res => {
      if (res && res.data && res.data.src) {
        // 截去域名，保留相对资源路径
        var regex = new RegExp(/(\w+):\/\/([^/:]+)(:\d*)/g)
        res = {
          src: res.data.src.replace(regex, ''),
          title: res.data.title,
          suffix: res.data.suffix
        }
        resove(res)
      } else {
        reject(res)
      }
    })
  })
}