import { axios } from '@/utils/request'

/** 登录、注册、找回密码的api */
const api = {
  Login: '/auth/login',
  Logout: '/auth/logout',
  ForgePassword: '/auth/forge-password',
  Register: '/auth/register',
  SendSms: '/account/sms',
  SendSmsErr: '/account/sms_err',
  UserInfo: '/user/info'
}

/**
 * login func
 * parameter: {
 *     username: '',
 *     password: '',
 *     remember_me: true,
 *     captcha: '12345'
 * }
 * @param parameter
 * @returns {*}
 */
export function login(parameter) {
  return axios.post(api.Login, parameter)
}

export function getSmsCaptcha(parameter) {
  return axios.post(api.SendSms, parameter)
}

export function getInfo() {
  return axios.get('/manage/user/info')
}

export function logout() {
  return axios.post(api.Logout)
}