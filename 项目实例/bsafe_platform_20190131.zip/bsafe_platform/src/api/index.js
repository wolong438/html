import { axios } from '@/utils/request'

/** 首页api */
const api = {
  listXX: '/listXX',
  getXX: '/getXX',
  createXX: '/createXX',
  deleteXX: '/deleteXX',
  updateXX: '/updateXX'
}
export default api

/** 获取列表数据 */
export function listXX(parameter) {
  return axios.post(api.listXX, parameter)
}

/** 获取单条数据 */
export function getXX(parameter) {
  return axios.post(api.getXX, parameter)
}

/** 创建数据 */
export function createXX(parameter) {
  return axios.post(api.createXX, parameter)
}

/** 删除数据 */
export function deleteXX(parameter) {
  return axios.post(api.deleteXX, parameter)
}

/** 更新数据 */
export function updateXX(parameter) {
  return axios.post(api.updateXX, parameter)
}