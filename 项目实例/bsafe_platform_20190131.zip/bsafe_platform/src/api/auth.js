import { axios } from '@/utils/request'

/** 系统权限相关的api */
const api = {
  user: '/manage/user/list',
  createUser: '/manage/user/create',
  editUser: '/manage/user/update',
  deleteUser: '/manage/user/delete/',

  listRole: '/manage/role/list',
  createRole: '/manage/role/create',
  editRole: '/manage/role/update',
  deleteRole: '/manage/role/delete/',

  listPermission: '/manage/permission/list',
  createPermission: '/manage/permission/create',
  editPermission: '/manage/permission/update',
  deletePermission: '/manage/permission/delete/',

  service: '/service',
  permission: '/manage/permission',
  permissionNoPager: '/manage/permission/no-pager',
}

export default api

export function getUserList(parameter) {
  return axios({
    url: api.user,
    method: 'get',
    params: parameter
  })
}

export function createUser(parameter) {
  return axios({
    url: api.editUser,
    method: 'post',
    params: parameter
  })
}

export function editUser(parameter) {
  return axios.post(api.editUser, parameter)
}

export function deleteUser(parameter) {
  return axios({
    url: api.deleteUser + parameter,
    method: 'get'
  })
}

export function getRoleList(parameter) {
  return axios({
    url: api.listRole,
    method: 'get',
    params: parameter
  })
}
export function createRole(parameter) {
  return axios({
    url: api.editRole,
    method: 'post',
    params: parameter
  })
}

export function editRole(parameter) {
  return axios.post(api.editRole, parameter)
}

export function deleteRole(parameter) {
  return axios({
    url: api.deleteRole + parameter,
    method: 'get'
  })
}



export function getPermissionList(parameter) {
  return axios({
    url: api.listPermission,
    method: 'get',
    params: parameter
  })
}

export function createPermission(parameter) {
  return axios({
    url: api.editPermission,
    method: 'post',
    params: parameter
  })
}

export function editPermission(parameter) {
  return axios.post(api.editPermission, parameter)
}

export function deletePermission(parameter) {
  return axios({
    url: api.deletePermission + parameter,
    method: 'get'
  })
}

export function getPermissionTree(parameter) {
  return new Promise((resove, reject) => {
    getPermissionList(parameter).then(res => {
      // 生成映射关系{permission_id: permission}
      const map = {}
      res.result.forEach(permission => {
        map[permission.permission_id] = permission
      })
      // 遍历映射关系，组合父子节点
      for (var id in map) {
        const permission = map[id]
        const parentPermission = map[permission.pid]
        if (parentPermission) {
          if (!parentPermission.children) {
            parentPermission.children = []
          }
          parentPermission.children.push(permission)
        }
      }
      // 遍历映射关系，形成父节点数组（排除了子节点，因为子节点已经被存放到父节点下级去了）
      const permissionTree = []
      for (id in map) {
        if (map[id].type == 1) {
          permissionTree.push(map[id])
        }
      }
      // 返回结果
      resove(permissionTree)
    }).catch(error => {
      reject(error)
    })
  })
}


export function getServiceList(parameter) {
  return axios({
    url: api.service,
    method: 'get',
    params: parameter
  })
}

export function getPermissions(parameter) {
  return axios({
    url: api.permissionNoPager,
    method: 'get',
    params: parameter
  })
}

// id == 0 add     post
// id != 0 update  put
export function saveService(parameter) {
  return axios({
    url: api.service,
    method: parameter.id == 0 ? 'post' : 'put',
    data: parameter
  })
}

