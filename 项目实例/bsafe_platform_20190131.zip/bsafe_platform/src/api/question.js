import { axios } from '@/utils/request'

/** 帮助中心api */
const api = {
  listQuestion: '/system/question/getPage.do',
  getQuestion: '/system/question/detailView.do',
  createQuestion: '/system/question/saveQuestion.do',
  deleteQuestion: '/system/question/saveQuestion.do',
  showEditor: '/system/question/getDetail.do',
  
  listFeedBack: '/system/feedBack/getPage.do',
  createFeedback: '/system/feedBack/saveFeedBack.do',
  listFeedbackImg: '/system/feedBack/getDetail.do'
}

export default api

export function listQuestion(parameter) {
  return axios({
    url: api.listQuestion,
    method: 'post',
    params: parameter
  })
}

export function getQuestion(parameter) {
  return axios({
    url: api.getQuestion,
    method: 'post',
    params: parameter
  })
}

export function createQuestion(parameter) {
  return new Promise((resove, reject) => {
    axios({
      url: api.createQuestion,
      method: 'post',
      params: parameter
    }).then(response => {
      response.code == 200 ? resove(response) : reject(response)
    }).catch(error => {
      reject(error)
    })
  })
}

export function deleteQuestion(parameter) {
  return axios({
    url: api.deleteQuestion,
    method: 'post',
    params: parameter
  })
}

export function listFeedBack(parameter) {
  return axios({
    url: api.listFeedBack,
    method: 'post',
    params: parameter
  })
}

export function createFeedback(parameter) {
  return axios({
    url: api.createFeedback,
    method: 'post',
    params: parameter
  })
}

export function listFeedbackImg(parameter) {
  return axios({
    url: api.listFeedbackImg,
    method: 'post',
    params: parameter
  })
}