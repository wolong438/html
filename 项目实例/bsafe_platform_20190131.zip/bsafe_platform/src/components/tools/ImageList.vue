<template>
  <viewer 
    @inited="inited"
    :options="options"
    :images="images"
    class="viewer"
    ref="viewer">
    <template slot-scope="scope">
      <img class="image" v-for="src in scope.images" :src="src" :key="src">
    </template>
  </viewer>
</template>
<script>
  import 'viewerjs/dist/viewer.css'
  import Viewer from 'v-viewer/src/component.vue'

  // 参考地址：
  // https://mirari.cc/v-viewer/
  // https://fengyuanchen.github.io/viewerjs/
  // http://www.dowebok.com/192.html

  //测试数据
  // const images = [
  //   'http://static.lagou.com/thumbnail_600x360/image1/M00/41/9E/Cgo8PFXJScyAYt1eAAOzza0wu3o363.png',
  //   'http://img.iyoucai.com/pageSet/201612/1B9B30D6066A472.jpg',
  //   'http://img.zcool.cn/community/01120455447f0f0000019ae94f9713.jpg',
  //   'http://image.woshipm.com/wp-files/2013/10/59b2900aa03cb2182a51cdb520b535b6.png.png',
  //   'http://c.hiphotos.baidu.com/baike/c0%3Dbaike272%2C5%2C5%2C272%2C90%3Bt%3Dgif/sign=fce8c9513d6d55fbd1cb7e740c4b242f/cb8065380cd791234da231fbad345982b3b780fb.jpg'
  // ]
  const options = {
    inline: false,
    button: true,
    navbar: true,
    title: false,
    toolbar: true,
    tooltip: true,
    movable: true,
    zoomable: true,
    rotatable: true,
    scalable: true,
    transition: true,
    fullscreen: true,
    keyboard: true,
    url: 'data-source'
  }
  const form = {
    view: 2,
    zoom: -0.1,
    zoomTo: 0.8,
    rotate: 90,
    rotateTo: 180,
    scaleX: 1,
    scaleY: 1
  }

  export default {
    components: {
      Viewer
    },
    props: {
      images: {
        type: Array,
        default: () => {
          return []
        }
      },
      initialOptions: {
        type: Object,
        default: () => {}
      },
      initialForm: {
        type: Object,
        default: () => {}
      }
    },
    data() {
      return {
        options: Object.assign({}, options, this.initialOptions),
        form: Object.assign({}, form, this.initialForm)
      }
    },
    mounted() {
      //console.log(this.options, this.form)
    },
    methods: {
      inited (viewer) {
        this.$viewer = viewer
      },
      add () {
        //this.images.push(sourceImages[this.images.length])
      },
      remove () {
        this.images.pop()
      },
      view () {
        if (this.form.view >= 0 && this.form.view < this.images.length) {
          this.$viewer.view(this.form.view)
        }
      },
      zoom (value) {
        this.$viewer.zoom(value || this.form.zoom)
      },
      zoomTo () {
        this.$viewer.zoomTo(this.form.zoomTo)
      },
      rotate (value) {
        this.$viewer.rotate(value || this.form.rotate)
      },
      rotateTo () {
        this.$viewer.rotateTo(this.form.rotateTo)
      },
      scaleX (value) {
        if (value) {
          this.$viewer.scaleX(value)
        } else {
          this.form.scaleX = -this.form.scaleX
          this.$viewer.scaleX(this.form.scaleX)
        }
      },
      scaleY (value) {
        if (value) {
          this.$viewer.scaleY(value)
        } else {
          this.form.scaleY = -this.form.scaleY
          this.$viewer.scaleY(this.form.scaleY)
        }
      },
      move (x, y) {
        this.$viewer.move(x, y)
      },
      prev () {
        this.$viewer.prev()
      },
      next () {
        this.$viewer.next()
      },
      play () {
        this.$viewer.play()
      },
      stop () {
        this.$viewer.stop()
      },
      show () {
        this.$viewer.show()
      },
      full () {
        this.$viewer.full()
      },
      tooltip () {
        this.$viewer.tooltip()
      },
      reset () {
        this.$viewer.reset()
      },
      toggleInline (inline) {
        this.options.inline = inline
      }
    }
  }
</script>

<style scoped>
  .image {
    height: 70px;
    cursor: pointer;
    margin: 5px;
    display: inline-block;
    border: 1px solid #ddd;
  }
</style>