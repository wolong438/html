<template>
  <a-modal
    :title="title"
    :width="900"
    :visible="visible"
    :confirmLoading="confirmLoading"
    @ok="handleOk"
    @cancel="handleCancel"
  >
    <a-spin :spinning="confirmLoading">
      <a-form :form="form">
        <a-form-item>
          <a-input type="hidden" v-decorator="['FAQ_ID']"/>
        </a-form-item>
        
        <a-form-item 
          :labelCol="labelCol"
          :wrapperCol="wrapperCol"
          label="类型">
          <a-select @change="handleFaqTypeChange" :disabled="disabled" v-decorator="['FAQ_TYPE', {rules: [{ required: true, message: '请选择问题类型'}]}]">
            <a-select-option v-for="(val, key) in faqType" :key="Number(key)">{{ val }}</a-select-option>
          </a-select>
        </a-form-item>

        <a-form-item 
          :labelCol="labelCol"
          :wrapperCol="wrapperCol"
          label="类别">
          <a-select :disabled="disabled" v-decorator="['FAQ_KIND', {rules: [{ required: true, message: '请选择问题类别'}]}]">
            <a-select-option v-for="(val, key) in faqKind" :key="Number(key)">{{ val }}</a-select-option>
          </a-select>
        </a-form-item>

        <a-form-item 
          :labelCol="labelCol"
          :wrapperCol="wrapperCol"
          label="标题">
          <a-input :disabled="disabled" placeholder="请输入" v-decorator="['FAQ_TITEL', {rules: [{ required: true, message: '请填写问题标题'}]}]"/>
        </a-form-item>
      </a-form>
      <a-form-item 
        :labelCol="labelCol"
        :wrapperCol="wrapperCol"
        label="详情">
        <tinymce-editor ref="editor"></tinymce-editor> 
      </a-form-item >
      
    </a-spin>
  </a-modal>
</template>

<script>
  import TinymceEditor from '@/components/Editor/TinymceEditor'
  import {createQuestion} from '@/api/question'

  const faqTypeData = { 1: '二代机', 2: '记录仪'}
  const faqKindData = [
    {},
    {
      0: '人脸问题', 
      1: '登录问题', 
      2: '业务问题', 
      3: '版本更新问题', 
      4: '库存问题', 
      5: '同步问题', 
      6: '远程问题', 
      7: '设备问题', 
      8: '其他问题'
    },
    {
      0: '人脸问题', 
      1: '登录问题', 
      2: '业务问题', 
      3: '版本更新问题',
      5: '同步问题', 
      6: '远程问题', 
      7: '设备问题', 
      8: '其他问题'
    }
  ]

  export default {
    name: 'QuestionModal',
    components: {
      TinymceEditor
    },
    data () {
      return {
        labelCol: {
          xs: { span: 24 },
          sm: { span: 5 },
        },
        wrapperCol: {
          xs: { span: 24 },
          sm: { span: 16 },
        },
        faqTypeData,
        faqKindData,
        faqType: faqTypeData,
        faqKind: faqKindData[1],
        mdl: {},
        title: '常见问题',
        visible: false,
        disabled: false,
        actionType: 'view',
        confirmLoading: false,
        form: this.$form.createForm(this)
      }
    },
    created () {
    },
    methods: {
      add (record) {
        this.title = '常见问题 - 新增'
        this.visible = true
        this.disabled = false
        this.actionType = 'add'
        this.fill(record)
      },
      edit (record) {
        this.title = '常见问题 - 编辑'
        this.visible = true
        this.disabled = false
        this.actionType = 'update'
        this.fill(record)
      },
      view (record) {
        this.title = '常见问题 - 详情'
        this.visible = true
        this.disabled = true
        this.actionType = 'view'
        this.fill(record)
      },
      fill (record) {
        this.mdl = Object.assign({}, record)
        this.$nextTick(() => {
          this.form.setFieldsValue(this.mdl)
        })
        // 组件还未初始化时，延迟设置内容
        var self = this
        setTimeout(() => {
          var editor = self.$refs.editor
          editor.setContent(record.FAQ_SOLUTION)
          editor.setReadonly(this.disabled)
        }, 500)
      },
      close () {
        this.visible = false
        this.form.resetFields()
        this.$refs.editor.clear()
      },
      handleOk () {
        const _this = this
        if (_this.actionType == 'view') {
          _this.close()
          return
        }

        // 表单验证
        _this.form.validateFields((err, values) => {
          if (!err) {
            values['type'] = _this.actionType
            values['FAQ_SOLUTION'] = _this.$refs.editor.getContent()
            _this.confirmLoading = true
            createQuestion(values).then(() => {
              _this.$message.success('保存成功')
              _this.$emit('ok')
              _this.close()
            }).catch((res) => {
              _this.$message.error(res.message || '保存失败')
            }).finally(() => {
              _this.confirmLoading = false
            })
          }
        })
      },
      handleCancel () {
        this.close()
      },
      handleFaqTypeChange (value) {
        this.faqKind = this.faqKindData[value]
        this.form.setFieldsValue({'FAQ_KIND': ''})
      },
    }
  }
</script>

<style scoped>

</style>