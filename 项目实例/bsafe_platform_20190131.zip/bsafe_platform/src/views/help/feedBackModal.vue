<template>
  <a-modal
    :title="title"
    :width="900"
    :visible="visible"
    :confirmLoading="confirmLoading"
    @ok="handleOk"
    @cancel="handleCancel"
  >
    <a-spin :spinning="confirmLoading">
      <a-form :form="form">
        <a-form-item>
          <a-input type="hidden" v-decorator="['FB_ID']"/>
        </a-form-item>

        <a-form-item 
          :labelCol="labelCol"
          :wrapperCol="wrapperCol"
          label="反馈内容">
          <a-textarea v-decorator="['TB_CONTENT']" autosize disabled/>
        </a-form-item>

        <a-form-item 
          :labelCol="labelCol"
          :wrapperCol="wrapperCol"
          label="联系人">
          <a-input v-decorator="['LINK_MAN']" disabled/>
        </a-form-item>

        <a-form-item 
          :labelCol="labelCol"
          :wrapperCol="wrapperCol"
          label="联系方式">
          <a-input v-decorator="['LINK_WAY']" disabled/>
        </a-form-item>

        <a-form-item 
          :labelCol="labelCol"
          :wrapperCol="wrapperCol"
          label="附件">
          <image-list :images="images"></image-list>
        </a-form-item>
        

        <div v-if="!mdl.IS_DISPOSE">
          <a-form-item 
            :labelCol="labelCol"
            :wrapperCol="wrapperCol"
            label="处理备注">
            <a-textarea v-decorator="['DISPOSE_REMARK', {rules: [{ required: true, message: '请输入处理备注'}]}]" autosize/>
          </a-form-item>
        </div>

        <div v-if="mdl.IS_DISPOSE">
          <a-form-item 
            :labelCol="labelCol"
            :wrapperCol="wrapperCol"
            label="处理备注">
            <a-textarea v-decorator="['DISPOSE_REMARK']" autosize disabled/>
          </a-form-item>
          <a-form-item 
            :labelCol="labelCol"
            :wrapperCol="wrapperCol"
            label="处理状态">
            <a-select v-decorator="['IS_DISPOSE']" disabled>
              <a-select-option :value="0">未处理</a-select-option>
              <a-select-option :value="1">已处理</a-select-option>
            </a-select>
          </a-form-item>

          <a-form-item 
            :labelCol="labelCol"
            :wrapperCol="wrapperCol"
            label="处理人">
            <a-input v-decorator="['DISPOSE_MAN']" disabled/>
          </a-form-item>

          <a-form-item 
            :labelCol="labelCol"
            :wrapperCol="wrapperCol"
            label="处理时间">
            <a-input v-decorator="['DISPOSE_TIME']" disabled/>
          </a-form-item>
        </div>
      </a-form>
    </a-spin>
  </a-modal>
</template>

<script>
  import {listFeedbackImg, createFeedback} from '@/api/question'
  import ImageList from '@/components/tools/ImageList'

  export default {
    name: 'FeedbackModal',
    components: {
      ImageList
    },
    data () {
      return {
        labelCol: {
          xs: { span: 24 },
          sm: { span: 5 },
        },
        wrapperCol: {
          xs: { span: 24 },
          sm: { span: 16 },
        },
        title: '意见反馈',
        visible: false,
        confirmLoading: false,
        form: this.$form.createForm(this),
        mdl: {},
        images: []
      }
    },
    methods: {
      listImage(fbId) {
        const params = {FB_ID: fbId}
        listFeedbackImg(params).then(res => {
          if (!(res.librarys instanceof Array)) {
            res.librarys = []
          }
          const librarys = res.librarys.map(item => {
            return item.ACC_PATH
          })
          this.images = librarys
        }).catch(error => {
          console.log(error)
        })
      },
      view (record) {
        this.title = '意见反馈 - 详情'
        this.visible = true
        this.disabled = true
        this.actionType = 'view'
        this.fill(record)
      },
      edit (record) {
        this.title = '意见反馈 - 处理'
        this.visible = true
        this.disabled = false
        this.actionType = 'update'
        this.fill(record)
      },
      fill (record) {
        this.mdl = Object.assign({}, record)
        this.mdl.IS_DISPOSE = this.mdl.IS_DISPOSE ? 1 : 0
        this.$nextTick(() => {
          this.form.setFieldsValue(this.mdl)
        })
        this.listImage(this.mdl.FB_ID)
      },
      close () {
        this.visible = false
        this.form.resetFields()
      },
      handleOk () {
        const _this = this
        if (_this.actionType == 'view') {
          _this.close()
          return
        }

        // 表单验证
        _this.form.validateFields((err, values) => {
          console.log(values)
          if (!err) {
            _this.$confirm({
              title: '确定提交处理?',
              onOk() {
                const params = {
                  'type' : 'handle',
                  'DISPOSE_REMARK' : values.DISPOSE_REMARK,
                  'FB_ID' : values.FB_ID
                }
                _this.confirmLoading = true
                createFeedback(params).then(() => {
                  _this.$message.success('操作成功')
                  _this.$emit('ok')
                  _this.close()
                }).catch((res) => {
                  _this.$message.error(res.message || '操作失败')
                }).finally(() => {
                  _this.confirmLoading = false
                })
              },
              onCancel() {}
            })
          }
        })
      },
      handleCancel () {
        this.close()
      }
    }
  }
</script>

<style scoped>

</style>