<template>
  <a-card :bordered="false">
    <div class="table-page-search-wrapper">
      <a-form layout="inline" @submit="handleQuery" :form="form">
        <a-row :gutter="48">
          <a-col :md="6" :sm="24">
            <a-form-item label="意见类型">
              <a-select placeholder="请选择" v-model="queryParam.FB_TYPE">
                <a-select-option v-for="(val, key) in fbType" :key="key">{{ val }}</a-select-option>
              </a-select>
            </a-form-item>
          </a-col>
          <a-col :md="6" :sm="24">
            <a-form-item label="联系人">
              <a-input placeholder="请输入" v-model="queryParam.LINK_MAN"/>
            </a-form-item>
          </a-col>
          <a-col :md="6" :sm="24">
            <a-form-item label="是否处理">
              <a-select placeholder="请选择" v-model="queryParam.IS_DISPOSE">
                <a-select-option v-for="(val, key) in disposeType" :key="key">{{ val }}</a-select-option>
              </a-select>
            </a-form-item>
          </a-col>
          <a-col :md="6" :sm="24">
            <span class="table-page-search-submitButtons">
              <a-button type="primary" htmlType='submit'>查询</a-button>
            </span>
          </a-col>
        </a-row>
      </a-form>
    </div>

    <s-table
      ref="table"
      size="default"
      :columns="columns"
      :data="loadData"
    >

      <template slot="ctime">
        {{ '' | timestampFilter }}
      </template>

      <template slot="type" slot-scope="text">
        {{ text | typeFilter }}
      </template>

      <template slot="dispose" slot-scope="text">
        {{ text | disposeFilter }}
      </template>

      <span slot="action" slot-scope="text, record">
        <a @click="handleView(record)" v-show="record.IS_DISPOSE == 1">详情</a>
        <a @click="handleEdit(record)" v-show="record.IS_DISPOSE == 0">处理</a>
      </span>
    </s-table>
    <feedback-modal ref="modal" @ok="handleOk"></feedback-modal>
  </a-card>
</template>

<script>
  import STable from '@/components/table/'
  import FeedbackModal from '@/views/help/feedBackModal.vue'
  import {listFeedBack} from '@/api/question'
  import {pageDataAdapter, pageParamsAdapter, formatDate} from '@/utils/util'

  const fbType = {'': '请选择', '1': '二代机', '2': '记录仪'}
  const disposeType = {'': '请选择', '0': '未处理', '1': '已处理'}

  export default {
    name: 'TableList',
    components: {
      STable,
      FeedbackModal
    },
    data () {
      return {
        form: this.$form.createForm(this),
        fbType,
        disposeType,
        queryParam: {
          FB_TYPE: '',
          LINK_MAN: '',
          IS_DISPOSE: '',
          jumpTo: 0
        },
        // 表头
        columns: [
          {
            title: '问题类型',
            dataIndex: 'FB_TYPE',
            scopedSlots: { customRender: 'type' }
          },
          {
            title: '意见内容',
            dataIndex: 'TB_CONTENT'
          },
          {
            title: '联系人',
            dataIndex: 'LINK_MAN'
          },
          {
            title: '联系方式',
            dataIndex: 'LINK_WAY'
          },
          {
            title: '提交时间',
            dataIndex: 'COMMIT_TIME',
            scopedSlots: { customRender: 'ctime' }
          },
          {
            title: '是否处理',
            dataIndex: 'IS_DISPOSE',
            scopedSlots: { customRender: 'dispose' }
          },
          {
            title: '处理人',
            dataIndex: 'DISPOSE_MAN'
          },
          {
            title: '处理时间',
            dataIndex: 'DISPOSE_TIME',
            scopedSlots: { customRender: 'ctime' }
          },
          {
            title: '操作',
            scopedSlots: { customRender: 'action' }
          }
        ],
        // 加载数据方法 必须为 Promise 对象
        loadData: parameter => {
          const params = Object.assign(pageParamsAdapter(parameter), this.queryParam)
          if (params.jumpTo > 0) {
            params.pageNow = params.jumpTo
            this.queryParam.jumpTo = 0
          }
          return listFeedBack(params)
            .then(res => {
              const data = pageDataAdapter(res)
              return data
            })
        },
      }
    },
    filters: {
      timestampFilter(timestamp) {
        const date = new Date(timestamp)
        return formatDate(date)
      },

      typeFilter(key) {
        return fbType[key]
      },

      disposeFilter(key) {
        key = key ? 1 : 0
        return disposeType[key]
      }
    },
    methods: {
      handleQuery (e) {
        e.preventDefault()
        console.log(this.form.getFieldsValue())
        Object.assign(this.queryParam, this.form.getFieldsValue(), {jumpTo: 1})
        this.$refs.table.refresh()
      },
      handleOk () {
        this.$refs.table.refresh()
      },
      handleView (record) {
        this.$refs.modal.view(record)
      },
      handleEdit (record) {
        this.$refs.modal.edit(record)
      }
    }
  }
</script>