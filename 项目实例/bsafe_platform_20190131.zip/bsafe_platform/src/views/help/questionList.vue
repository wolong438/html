<template>
  <a-card :bordered="false">
    <div class="table-page-search-wrapper">
      <a-form layout="inline" @submit="handleQuery" :form="form">
        <a-row :gutter="48">
          <a-col :md="6" :sm="24">
            <a-form-item label="问题类型">
              <a-select placeholder="请选择" defaultValue="" v-model="queryParam.FAQ_TYPE" @change="handleFaqTypeChange">
                <a-select-option v-for="(val, key) in faqType" :key="key">{{ val }}</a-select-option>
              </a-select>
            </a-form-item>
          </a-col>
          <a-col :md="6" :sm="24">
            <a-form-item label="问题类别">
              <a-select placeholder="请选择" defaultValue="" v-model="queryParam.FAQ_KIND">
                <a-select-option v-for="(val, key) in faqKind" :key="key">{{ val }}</a-select-option>
              </a-select>
            </a-form-item>
          </a-col>
          <a-col :md="6" :sm="24">
            <a-form-item label="最后修改人">
              <a-input placeholder="请输入" v-model="queryParam.LAST_MODIFIER"/>
            </a-form-item>
          </a-col>
          <a-col :md="6" :sm="24">
            <span class="table-page-search-submitButtons">
              <a-button type="primary" htmlType='submit'>查询</a-button>
              <a-button style="margin-left: 8px" @click="handleAdd">新增</a-button>
              <a-button style="margin-left: 8px" @click="handleDelete">删除</a-button>
            </span>
          </a-col>
        </a-row>
      </a-form>
    </div>

    <s-table
      ref="table"
      size="default"
      :columns="columns"
      :data="loadData"
      :rowSelection="{selectedRowKeys: selectedRowKeys, selectedRows: selectedRows, onChange: onSelectChange}"
    >

      <span slot="ctime" slot-scope="text">
        {{ text | timestampFilter }}
      </span>

      <span slot="type" slot-scope="text">
        {{ text | typeFilter }}
      </span>

      <span slot="kind" slot-scope="text">
        {{ text | kindFilter }}
      </span>

      <span slot="button" slot-scope="text, record">
        <a @click="handleEdit(record)">编辑</a>
        <a-divider type="vertical" />
        <a @click="handleView(record)">详情</a>
      </span>
    </s-table>

    <question-modal ref="modal" @ok="handleOk"></question-modal>
  </a-card>
</template>

<script>
  import STable from '@/components/table/'
  import QuestionModal from '@/views/help/questionModal.vue'
  import {listQuestion, deleteQuestion} from '@/api/question'
  import {pageDataAdapter, pageParamsAdapter, formatDate} from '@/utils/util'

  const faqTypeData = {'': '请选择', '1': '二代机', '2': '记录仪'}
  const faqKindData = [
    {},
    {
      '': '请选择',
      '0': '人脸问题', 
      '1': '登录问题', 
      '2': '业务问题', 
      '3': '版本更新问题', 
      '4': '库存问题', 
      '5': '同步问题', 
      '6': '远程问题', 
      '7': '设备问题', 
      '8': '其他问题'
    },
    {
      '': '请选择',
      '0': '人脸问题', 
      '1': '登录问题', 
      '2': '业务问题', 
      '3': '版本更新问题', 
      '5': '同步问题', 
      '6': '远程问题', 
      '7': '设备问题', 
      '8': '其他问题'
    }
  ]


  export default {
    name: 'TableList',
    components: {
      STable,
      QuestionModal,
    },
    data () {
      return {
        form: this.$form.createForm(this),
        selectedRowKeys: [],
        selectedRows: [],
        // 高级搜索 展开/关闭
        advanced: false,
        // 查询参数
        queryParam: {
          FAQ_TYPE: '',
          FAQ_KIND: '',
          LAST_MODIFIER: '',
          jumpTo: 0
        },
        // 表头
        columns: [
          {
            title: '问题类型',
            dataIndex: 'FAQ_TYPE',
            scopedSlots: { customRender: 'type' },
          },
          {
            title: '问题类别',
            dataIndex: 'FAQ_KIND',
            scopedSlots: { customRender: 'kind' }
          },
          {
            title: '问题标题',
            dataIndex: 'FAQ_TITEL',
          },
          {
            title: '最后修改人',
            dataIndex: 'LAST_MODIFIER',
          },
          {
            title: '最后修改时间',
            dataIndex: 'LAST_MODIFY_TIME',
            scopedSlots: { customRender: 'ctime' }
          },
          {
            title: '操作',
            dataIndex: 'operation',
            scopedSlots: { customRender: 'button' }
          }
        ],
        faqTypeData,
        faqKindData,
        faqType: faqTypeData,
        faqKind: faqKindData[1],

        // 加载数据方法 必须为 Promise 对象
        loadData: parameter => {
          const params = Object.assign(pageParamsAdapter(parameter), this.queryParam)
          if (params.jumpTo > 0) {
            params.pageNow = params.jumpTo
            this.queryParam.jumpTo = 0
          }
          return listQuestion(params)
            .then(res => {
              const data = pageDataAdapter(res)
              const data2 = {
                ...data,
                'data': data.data.map(function(item){
                  return {
                    ...item,
                    'key': item.FAQ_ID
                  }
                })
              }
              return data2
            })
        },
      }
    },
    filters: {
      timestampFilter(timestamp) {
        const date = new Date(timestamp)
        return formatDate(date)
      },

      typeFilter(value) {
        return faqTypeData[value]
      },

      kindFilter(value) {
        return faqKindData['1'][value]
      }
    },
    methods: {
      handleQuery (e) {
        e.preventDefault()
        Object.assign(this.queryParam, this.form.getFieldsValue(), {jumpTo: 1})
        this.$refs.table.refresh()
      },
      onSelectChange (selectedRowKeys, selectedRows) {
        this.selectedRowKeys = selectedRowKeys
        this.selectedRows = selectedRows
      },
      handleDelete () {
        const selectedRows = this.selectedRows
        //获取删除的id
        const ids = []
        for(let i=0; i<selectedRows.length; i++){
          ids.push(selectedRows[i].FAQ_ID)
        }
        const delete_id = ids.join(',')

        const _this = this
        const params = {
          type: 'delete',
          FAQ_ID: delete_id
        }
        //删除请求
        if(ids.length > 0){
          deleteQuestion(params).then(res => {
            _this.$message.success(res.msg)
            _this.$refs.table.refresh()
            _this.deselect()
          }).catch(error => {
            console.log(error)
          })
        }else{
           _this.$message.error('请勾选需要删除的数据！')
        }
      },
      handleAdd () {
        const record = {}
        this.$refs.modal.add(record)
      },
      handleView (record) {
        this.$refs.modal.view(record)
      },
      handleEdit (record) {
        this.$refs.modal.edit(record)
      },
      handleOk () {
        // 新增/修改 成功时，重载列表
        this.$refs.table.refresh()
      },
      toggleAdvanced () {
        this.advanced = !this.advanced
      },
      handleFaqTypeChange (value) {
        this.faqKind = this.faqKindData[value]
        this.form.setFieldsValue({'FAQ_KIND': ''})
      },
      deselect () {
        this.selectedRowKeys = []
        this.selectedRows = []
      }
    },
    computed: {
      hasSelected() {
        return this.selectedRowKeys.length > 0
      }
    }
  }
</script>