<template>
  <div class="home">
    <a-card style="margin-bottom: 3rem">
      <tinymce-editor></tinymce-editor>
    </a-card>
  </div>
</template>

<script>
  // @ is an alias to /src

  import Trend from '@/components/Trend'
  import AvatarList from '@/components/AvatarList'
  import CountDown from '@/components/CountDown/CountDown'
  import Ellipsis from '@/components/Ellipsis'
  import NumberInfo from '@/components/NumberInfo'
  import TinymceEditor from '@/components/Editor/TinymceEditor'

  const AvatarListItem = AvatarList.AvatarItem

  export default {
    name: 'Home',
    components: {
      NumberInfo,
      Ellipsis,
      CountDown,
      Trend,
      AvatarList,
      AvatarListItem,
      TinymceEditor
    },
    data () {
      return {
        targetTime: new Date().getTime() + 3900000
      }
    },
    methods: {
      onEndHandle () {
        this.$message.success('CountDown callback!!!')
      },
      onEndHandle2 () {
        this.$notification.open({
          message: 'Notification Title',
          description: 'This is the content of the notification.',
        })
      }
    }
  }
</script>

<style scoped>
  .home {
    width: 900px;
    margin: 0 auto;
    padding: 25px 0;
  }
  .home > .banner {
    text-align: center;
    padding: 25px 0;
    margin: 25px 0;
  }
</style>
