<template>
  <a-card :bordered="false">
    <div class="table-page-search-wrapper">
      <a-form layout="inline">
        <a-row :gutter="48">
          <a-col :md="8" :sm="24">
            <a-form-item label="账号">
              <a-input placeholder="请输入"/>
            </a-form-item>
          </a-col>
          <a-col :md="8" :sm="24">
            <a-form-item label="状态">
              <a-select placeholder="请选择" default-value="0">
                <a-select-option value="0">全部</a-select-option>
                <a-select-option value="1">关闭</a-select-option>
                <a-select-option value="2">运行中</a-select-option>
              </a-select>
            </a-form-item>
          </a-col>
          <a-col :md="8" :sm="24">
            <span class="table-page-search-submitButtons">
              <a-button type="primary">查询</a-button>
              <a-button style="margin-left: 8px">重置</a-button>
              <a-button style="margin-left: 8px">新增</a-button>
            </span>
          </a-col>
        </a-row>
      </a-form>
    </div>

    <s-table
      size="default"
      :columns="columns"
      :data="loadData"
    >
      <div
        slot="expandedRowRender"
        slot-scope="record"
        style="margin: 0">
        <a-row
          :gutter="24"
          :style="{ marginBottom: '12px' }">
          <a-col :span="12" v-for="(permission, index) in record.permissions" :key="index" :style="{ marginBottom: '12px' }">
            <a-col :lg="4" :md="24">
              <span>{{ permission.name }}：</span>
            </a-col>
            <a-col :lg="20" :md="24" v-if="permission.children.length > 0">
              <a-tag color="cyan" v-for="(action, k) in permission.children" :key="k">{{ action.name }}</a-tag>
            </a-col>
            <a-col :span="20" v-else>-</a-col>
          </a-col>
        </a-row>
      </div>

      <span slot="status" slot-scope="text">
        {{ text | statusFilter }}
      </span>
      <span slot="ctime" slot-scope="text">
        {{ text | dayjs }}
      </span>

      <span slot="action" slot-scope="text, record">
        <a @click="handleEdit(record)">编辑</a>
        <a-divider type="vertical" />
        <a-dropdown>
          <a class="ant-dropdown-link">
            更多 <a-icon type="down" />
          </a>
          <a-menu slot="overlay">
            <a-menu-item>
              <a href="javascript:;">详情</a>
            </a-menu-item>
            <a-menu-item>
              <a href="javascript:;">禁用</a>
            </a-menu-item>
            <a-menu-item>
              <a href="javascript:;">删除</a>
            </a-menu-item>
          </a-menu>
        </a-dropdown>
      </span>
    </s-table>

    <a-modal
      title="操作"
      style="top: 20px;"
      :width="900"
      v-model="visible"
      @ok="handleOk"
    >
      <a-form :autoFormCreate="(form)=>{this.form = form}">

        <a-form-item
          :labelCol="labelCol"
          :wrapperCol="wrapperCol"
          label='账号'
          hasFeedback
          validateStatus='success'
        >
          <a-input placeholder='账号' v-model="mdl.username" id='username' disabled="disabled" />
        </a-form-item>

        <a-form-item
          :labelCol="labelCol"
          :wrapperCol="wrapperCol"
          label='密码'
          hasFeedback
          validateStatus='success'
        >
          <a-input placeholder='密码' v-model="mdl.password" id='password' disabled="disabled" />
        </a-form-item>

        <a-form-item
          :labelCol="labelCol"
          :wrapperCol="wrapperCol"
          label='昵称'
          hasFeedback
          validateStatus='success'
        >
          <a-input placeholder='起一个名字' v-model="mdl.realname" id='realname' />
        </a-form-item>

        <a-form-item
          :labelCol="labelCol"
          :wrapperCol="wrapperCol"
          label='状态'
          hasFeedback
          validateStatus='warning'
        >
          <a-select v-model="mdl.status">
            <a-select-option value='1'>正常</a-select-option>
            <a-select-option value='2'>禁用</a-select-option>
          </a-select>
        </a-form-item>

        <a-divider />

        <a-form-item 
          :labelCol="labelCol"
          :wrapperCol="wrapperCol"
          label='拥有权限'
          hasFeedback>
          <a-row :gutter="16" v-for="(permission, index) in permissions" :key="index">
            <a-col :span="5">
              {{ permission.name }}：
            </a-col>
            <a-col :span="19">
              <a-checkbox
                v-if="permission.actionsOptions.length > 0"
                :indeterminate="permission.indeterminate"
                :checked="permission.checkedAll"
                @change="onChangeCheckAll($event, permission)">
                全选
              </a-checkbox>
              <a-checkbox-group :options="permission.actionsOptions" v-model="permission.selected" @change="onChangeCheck(permission)" />
            </a-col>
          </a-row>
        </a-form-item>

      </a-form>
    </a-modal>

  </a-card>
</template>

<script>
  import STable from '@/components/table/'
  import {getUserList, getPermissions } from '@/api/manage'
  // import { actionToObject } from '@/utils/permissions'
  import pick from 'lodash.pick'

  export default {
    name: 'TableList',
    components: {
      STable
    },
    data () {
      return {
        description: '列表使用场景：后台管理中的权限管理以及角色管理，可用于基于 RBAC 设计的角色权限控制，颗粒度细到每一个操作类型。',

        visible: false,
        labelCol: {
          xs: { span: 24 },
          sm: { span: 5 },
        },
        wrapperCol: {
          xs: { span: 24 },
          sm: { span: 16 },
        },
        form: this.$form.createForm(this),
        mdl: {},
        permissions: [],

        // 高级搜索 展开/关闭
        advanced: false,
        // 查询参数
        queryParam: {},
        // 表头
        columns: [
          {
            title: '账号',
            dataIndex: 'username'
          },
          {
            title: '昵称',
            dataIndex: 'realname',
          },
          {
            title: '角色',
            dataIndex: 'roles',
          },
          {
            title: '状态',
            dataIndex: 'status',
            scopedSlots: { customRender: 'status' }
          },
          {
            title: '创建时间',
            dataIndex: 'ctime',
            sorter: true,
            scopedSlots: { customRender: 'dayjs'}
          }, {
            title: '操作',
            width: '150px',
            dataIndex: 'action',
            scopedSlots: { customRender: 'action' },
          }
        ],
        // 加载数据方法 必须为 Promise 对象
        loadData: parameter => {
          return getUserList(parameter)
            .then(res => {
              return res.result
            })
        }
      }
    },
    created () {
      // getUserList().then(res => {
      //   console.log('getUserList.call()', res)
      // })

      // getRoleList().then(res => {
      //   console.log('getRoleList.call()', res)
      // })
      this.loadPermissions()
    },
    filters: {
      statusFilter(status) {
        const statusMap = {
          1: '正常',
          2: '禁用'
        }
        return statusMap[status]
      },
      timestampFilter() {

      }
    },
    methods: {
      handleEdit (record) {
        // this.mdl = Object.assign({}, record)

        // this.mdl.permissions.forEach(permission => {
        //   permission.actionsOptions = permission.children.map(action => {
        //     return { label: action.name, value: action.uri, defaultCheck: action.check }
        //   })
        // })

        // this.visible = true

        this.mdl = Object.assign({}, record)
        // 有权限表，处理勾选
        if (this.mdl.permissions && this.permissions) {
          // 先处理要勾选的权限结构
          const permissionsAction = {}
          this.mdl.permissions.forEach(permission => {
            permissionsAction[permission.id] = permission.children.map(entity => entity.id)
          })

          console.log('permissionsAction', permissionsAction)

          // 把权限表遍历一遍，设定要勾选的权限 action
          this.permissions.forEach(permission => {
            const selected = permissionsAction[permission.id]
            permission.selected =  selected || []
          })

          console.log('this.permissions', this.permissions)
        }

        this.$nextTick(() => {
          this.form.setFieldsValue(pick(this.mdl, 'id', 'name', 'status', 'describe'))
        })
        console.log('this.mdl', this.mdl)
        this.visible = true
      },
      handleOk () {

      },
      toggleAdvanced () {
        this.advanced = !this.advanced
      },
      onChangeCheck (permission) {
        permission.indeterminate = !!permission.selected.length && (permission.selected.length < permission.actionsOptions.length)
        permission.checkedAll = permission.selected.length === permission.actionsOptions.length
      },
      onChangeCheckAll (e, permission) {

        console.log('permission:', permission)

        Object.assign(permission, {
          selected: e.target.checked ? permission.actionsOptions.map(obj => obj.value) : [],
          indeterminate: false,
          checkedAll: e.target.checked
        })
      },
      addShowPermission () {

      },
      loadPermissions () {
        getPermissions().then(res => {console.log(res)
          const result = res.result
          this.permissions = result.map(permission => {
            permission.children.unshift({name: '可见', permission_id: '0'})
            return {
              id: permission.permission_id,
              name: permission.name,
              checkedAll: false,
              selected: [],
              indeterminate: false,
              actionsOptions : permission.children.map(child => {
                return {
                  label: child.name,
                  value: child.permission_id
                }
              })
            }
          })
        })
      }
    },
    watch: {
      /*
      'selectedRows': function (selectedRows) {
        this.needTotalList = this.needTotalList.map(item => {
          return {
            ...item,
            total: selectedRows.reduce( (sum, val) => {
              return sum + val[item.dataIndex]
            }, 0)
          }
        })
      }
      */
    }
  }
</script>