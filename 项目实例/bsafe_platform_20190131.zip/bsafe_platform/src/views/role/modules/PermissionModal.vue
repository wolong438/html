<template>
  <a-modal
    title="操作"
    :width="800"
    :visible="visible"
    :confirmLoading="confirmLoading"
    @ok="handleOk"
    @cancel="handleCancel"
  >
    <a-spin :spinning="confirmLoading">
      <a-form :form="form">

        <a-form-item
          :labelCol="labelCol"
          :wrapperCol="wrapperCol"
          label='名字'
          hasFeedback
        >
          <a-input v-show="false" v-decorator="[ 'permission_id']"/>
          <a-input v-show="false" v-decorator="[ 'pid']"/>
          <a-input placeholder='名字' autocomplete="false" v-decorator="[ 'name', {rules: [{ required: true, message: '请输入名字' }]} ]" />
        </a-form-item>

        <a-form-item
          :labelCol="labelCol"
          :wrapperCol="wrapperCol"
          label='类型'
          hasFeedback >
          <a-select v-decorator="[ 'type', {rules: [{ required: true, message: '请选择类型' }]} ]">
            <a-select-option :value="1">目录</a-select-option>
            <a-select-option :value="2">菜单</a-select-option>
            <a-select-option :value="3">按钮</a-select-option>
          </a-select>
        </a-form-item>

        <a-form-item
          :labelCol="labelCol"
          :wrapperCol="wrapperCol"
          label='权限值'
          hasFeedback
        >
          <a-input placeholder='权限值' autocomplete="false" v-decorator="[ 'permission_value', {rules: []} ]" />
        </a-form-item>

        <a-form-item
          :labelCol="labelCol"
          :wrapperCol="wrapperCol"
          label='链接'
          hasFeedback >
          <a-input placeholder='链接' autocomplete="false" v-decorator="[ 'uri', {rules: [] }]" />
        </a-form-item>

        <a-form-item
          :labelCol="labelCol"
          :wrapperCol="wrapperCol"
          label='图标'
          hasFeedback >
          <a-input placeholder='图标' autocomplete="false" v-decorator="[ 'icon', {rules: [] }]" />
        </a-form-item>

        <a-form-item
          :labelCol="labelCol"
          :wrapperCol="wrapperCol"
          label='序号'
          hasFeedback >
          <a-input-number :min="1" :max="100" autocomplete="false" v-decorator="[ 'orders']" style="width: 100%"/>
        </a-form-item>

        <a-form-item
          :labelCol="labelCol"
          :wrapperCol="wrapperCol"
          label='状态'
          hasFeedback >
          <a-select v-decorator="[ 'status']">
            <a-select-option :value="0">停用</a-select-option>
            <a-select-option :value="1">启用</a-select-option>
          </a-select>
        </a-form-item>

      </a-form>
    </a-spin>
  </a-modal>
</template>

<script>
  import { axios } from '@/utils/request'
  import { } from '@/api/auth'
  // import pick from 'lodash.pick'

  export default {
    name: 'UserModal',
    data () {
      return {
        labelCol: {
          xs: { span: 24 },
          sm: { span: 5 },
        },
        wrapperCol: {
          xs: { span: 24 },
          sm: { span: 16 },
        },
        visible: false,
        isUpdate: false,

        confirmLoading: false,
        mdl: {},

        form: this.$form.createForm(this),
        permissions: []
      }
    },
    created () {

    },
    methods: {
      edit (record) {
        this.mdl = Object.assign({}, record)
        this.visible = true
        this.isUpdate = record.permission_id ? true : false

        this.$nextTick(() => {
          this.form.setFieldsValue(record)
        })
        console.log('this.mdl', this.mdl)
      },
      save (parameter) {
        return new Promise((resove, reject) => {
          const url = this.isUpdate ? '/manage/permission/update' : '/manage/permission/create'
          axios.post(url, parameter)
          .then(response => {
            response.status === 200 ? resove(response) : reject(response)
          }).catch(error => {
            reject(error)
          })
        })
      },
      close () {
        // 弹框关闭时重置表单和权限选项
        this.$emit('close')
        this.visible = false
        this.form.resetFields()
      },
      handleOk () {
        const _this = this
        // 触发表单验证
        this.form.validateFields((err, values) => {
          // 验证表单没错误
          if (!err) {
            console.log(values)
            _this.confirmLoading = true
            _this.save(values).then(() => {
              _this.$message.success('保存成功')
              _this.$emit('ok')
              _this.close()
            }).catch((res) => {
              _this.$message.error(res.message || '保存失败')
            }).finally(() => {
              _this.confirmLoading = false
            })
          }
        })
      },
      handleCancel () {
        this.close()
      }
    }
  }
</script>

<style scoped>

</style>