<template>
  <a-modal
    title="操作"
    :width="900"
    :visible="visible"
    :confirmLoading="confirmLoading"
    @ok="handleOk"
    @cancel="handleCancel"
  >
    <a-spin :spinning="confirmLoading">
      <a-form :form="form">

        <a-form-item
          :labelCol="labelCol"
          :wrapperCol="wrapperCol"
          label='标识'
          hasFeedback
        >
          <a-input placeholder='标识' :disabled="isUpdate" autocomplete="false" v-decorator="[ 'name', {rules: [{ required: true, message: '请输入标识' }]} ]" />
        </a-form-item>

        <a-form-item
          :labelCol="labelCol"
          :wrapperCol="wrapperCol"
          label='名字'
          hasFeedback
        >
          <a-input placeholder='起个名字' :disabled="isUpdate" autocomplete="false" v-decorator="[ 'title', {rules: [{ required: true, message: '请输入名字' }]} ]" />
        </a-form-item>

        <a-form-item
          :labelCol="labelCol"
          :wrapperCol="wrapperCol"
          label='描述'
          hasFeedback
        >
          <a-input placeholder='描述' autocomplete="false" v-decorator="[ 'description', {rules: []} ]" />
        </a-form-item>

        <a-form-item
          :labelCol="labelCol"
          :wrapperCol="wrapperCol"
          label='序号'
          hasFeedback
        >
          <a-input placeholder='序号' autocomplete="false" v-decorator="[ 'orders', {rules: []} ]" />
        </a-form-item>

        <a-divider/>

        <a-form-item 
          :labelCol="labelCol"
          :wrapperCol="wrapperCol"
          label='拥有权限'
          hasFeedback>
          <a-row :gutter="16" v-for="(permission, index) in permissions" :key="index">
            <a-col :span="5">
              {{ permission.name }}：
            </a-col>
            <a-col :span="19">
              <a-checkbox
                v-if="permission.actionsOptions.length > 0"
                :indeterminate="permission.indeterminate"
                :checked="permission.checkedAll"
                @change="onChangeCheckAll($event, permission)">
                全选
              </a-checkbox>
              <a-checkbox-group :options="permission.actionsOptions" v-model="permission.selected" @change="onChangeCheck(permission)" />
            </a-col>
          </a-row>
        </a-form-item>

      </a-form>
    </a-spin>
  </a-modal>
</template>

<script>
  import { axios } from '@/utils/request'
  import { getPermissions } from '@/api/auth'
  import pick from 'lodash.pick'

  export default {
    name: 'RoleModal',
    data () {
      return {
        labelCol: {
          xs: { span: 24 },
          sm: { span: 5 },
        },
        wrapperCol: {
          xs: { span: 24 },
          sm: { span: 16 },
        },
        visible: false,
        isUpdate: false,

        confirmLoading: false,
        mdl: {},

        form: this.$form.createForm(this),
        permissions: []
      }
    },
    created () {
      this.loadPermissions()
    },
    methods: {
      add () {
        this.edit({orders: 1})
      },
      edit (record) {
        this.mdl = Object.assign({}, record)
        this.visible = true
        this.isUpdate = record.role_id ? true : false

        // 有权限表，处理勾选
        if (this.mdl.permissions && this.permissions) {
          // 先处理要勾选的权限结构,[{'permission_id1': [permission_id2, permission_id3, permission_id4]}]
          const permissionsAction = {}
          this.mdl.permissions.forEach(permission => {
            permissionsAction[permission.permission_id] = permission.children.map(entity => entity.permission_id)
            permissionsAction[permission.permission_id].push(permission.permission_id)
          })

          console.log('this.permissions',this.permissions, permissionsAction)
          // 把权限表遍历一遍，设定要勾选的权限 action
          this.permissions.forEach(permission => {
            permission.selected = permissionsAction[permission.id] || []
          })
        }

        this.$nextTick(() => {
          this.form.setFieldsValue(pick(this.mdl, 'role_id', 'name', 'title','description', 'orders'))
        })
        console.log('this.mdl', this.mdl)
      },
      save (parameter) {
        return new Promise((resove, reject) => {
          const url = this.isUpdate ? '/manage/role/update' : '/manage/role/create'
          axios.post(url, parameter)
          .then(response => {
            response.status === 200 ? resove(response) : reject(response)
          }).catch(error => {
            reject(error)
          })
        })
      },
      close () {
        // 弹框关闭时重置表单和权限选项
        this.$emit('close')
        this.visible = false
        this.form.resetFields()
        this.permissions.forEach(permission => {
          permission.checkedAll = false
          permission.selected = []
        })
      },
      handleOk () {
        const _this = this
        // 触发表单验证
        this.form.validateFields((err, values) => {
          // 验证表单没错误
          if (!err) {
            const permissionIds = []
            _this.permissions.forEach(permission => {
              permissionIds.push.apply(permissionIds, permission.selected)
            })
            values.permissionIds = permissionIds

            _this.confirmLoading = true
            _this.save(values).then(() => {
              _this.$message.success('保存成功')
              _this.$emit('ok')
              _this.close()
            }).catch((res) => {
              _this.$message.error(res.message || '保存失败')
            }).finally(() => {
              _this.confirmLoading = false
            })
          }
        })
      },
      handleCancel () {
        this.close()
      },
      onChangeCheck (permission) {
        permission.indeterminate = !!permission.selected.length && (permission.selected.length < permission.actionsOptions.length)
        permission.checkedAll = permission.selected.length === permission.actionsOptions.length
      },
      onChangeCheckAll (e, permission) {
        Object.assign(permission, {
          selected: e.target.checked ? permission.actionsOptions.map(obj => obj.value) : [],
          indeterminate: false,
          checkedAll: e.target.checked
        })
      },
      loadPermissions () {
        getPermissions().then(res => {
          const result = res.result
          this.permissions = result.map(permission => {
            permission.children.unshift({name: '可见', permission_id: permission.permission_id})
            return {
              id: permission.permission_id,
              name: permission.name,
              checkedAll: false,
              selected: [],
              indeterminate: false,
              actionsOptions : permission.children.map(child => {
                return {
                  label: child.name,
                  value: child.permission_id
                }
              })
            }
          })
        })
      }

    }
  }
</script>

<style scoped>

</style>