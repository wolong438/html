<template>
  <a-modal
    title="操作"
    :width="900"
    :visible="visible"
    :confirmLoading="confirmLoading"
    @ok="handleOk"
    @cancel="handleCancel"
  >
    <a-spin :spinning="confirmLoading">
      <a-form :form="form">

        <a-form-item
          :labelCol="labelCol"
          :wrapperCol="wrapperCol"
          label='账号'
          hasFeedback
        >
          <a-input placeholder='账号' :disabled="isUpdate" autocomplete="false" v-decorator="[ 'username', {rules: [{ required: true, message: '请输入账号' }]} ]" />
        </a-form-item>

        <a-form-item
          :labelCol="labelCol"
          :wrapperCol="wrapperCol"
          label='密码'
          hasFeedback
          v-if="!isUpdate"
        >
          <a-input placeholder='密码' type="password" autocomplete="false" v-decorator="[ 'password', {rules: [{ required: true, message: '请输入密码' }]} ]" />
        </a-form-item>

        <a-form-item
          :labelCol="labelCol"
          :wrapperCol="wrapperCol"
          label='昵称'
          hasFeedback >
          <a-input placeholder='起一个名字' autocomplete="false" v-decorator="[ 'realname', {rules: [] }]" />
        </a-form-item>

        <a-form-item
          :labelCol="labelCol"
          :wrapperCol="wrapperCol"
          label='状态'
          hasFeedback >
          <a-select v-decorator="[ 'locked', {rules: []} ]">
            <a-select-option :value="0">启用</a-select-option>
            <a-select-option :value="1">停用</a-select-option>
          </a-select>
        </a-form-item>

        <a-divider/>

        <a-form-item 
          :labelCol="labelCol"
          :wrapperCol="wrapperCol"
          label='拥有权限'
          hasFeedback>
          <a-row :gutter="16" v-for="(permission, index) in permissions" :key="index">
            <a-col :span="5">
              {{ permission.name }}：
            </a-col>
            <a-col :span="19">
              <a-checkbox
                v-if="permission.actionsOptions.length > 0"
                :indeterminate="permission.indeterminate"
                :checked="permission.checkedAll"
                @change="onChangeCheckAll($event, permission)">
                全选
              </a-checkbox>
              <a-checkbox-group :options="permission.actionsOptions" v-model="permission.selected" @change="onChangeCheck(permission)" />
            </a-col>
          </a-row>
        </a-form-item>

      </a-form>
    </a-spin>
  </a-modal>
</template>

<script>
  import { axios } from '@/utils/request'
  import { getPermissions } from '@/api/auth'
  import pick from 'lodash.pick'

  export default {
    name: 'UserModal',
    data () {
      return {
        labelCol: {
          xs: { span: 24 },
          sm: { span: 5 },
        },
        wrapperCol: {
          xs: { span: 24 },
          sm: { span: 16 },
        },
        visible: false,
        isUpdate: false,

        confirmLoading: false,
        mdl: {},

        form: this.$form.createForm(this),
        permissions: []
      }
    },
    created () {
      this.loadPermissions()
    },
    methods: {
      add () {
        this.edit({locked: 1})
      },
      edit (record) {
        this.mdl = Object.assign({}, record)
        this.visible = true
        this.isUpdate = record.user_id ? true : false

        // 有权限表，处理勾选
        if (this.mdl.permissions && this.permissions) {
          // 先处理要勾选的权限结构,[{'permission_id1': [permission_id2, permission_id3, permission_id4]}]
          const permissionsAction = {}
          this.mdl.permissions.forEach(permission => {
            permissionsAction[permission.permission_id] = permission.children.map(entity => entity.permission_id)
            permissionsAction[permission.permission_id].push(permission.permission_id)
          })

          console.log('this.permissions',this.permissions, permissionsAction)
          // 把权限表遍历一遍，设定要勾选的权限 action
          this.permissions.forEach(permission => {
            permission.selected = permissionsAction[permission.id] || []
          })
        }

        this.$nextTick(() => {
          this.form.setFieldsValue(pick(this.mdl, 'user_id', 'username', 'realname','password', 'locked'))
        })
        console.log('this.mdl', this.mdl)
      },
      save (parameter) {
        return new Promise((resove, reject) => {
          const url = this.isUpdate ? '/manage/user/update' : '/manage/user/create'
          axios.post(url, parameter)
          .then(response => {
            response.status === 200 ? resove(response) : reject(response)
          }).catch(error => {
            reject(error)
          })
        })
      },
      close () {
        // 弹框关闭时重置表单和权限选项
        this.$emit('close')
        this.visible = false
        this.form.resetFields()
        this.permissions.forEach(permission => {
          permission.checkedAll = false
          permission.selected = []
        })
      },
      handleOk () {
        const _this = this
        // 触发表单验证
        this.form.validateFields((err, values) => {
          // 验证表单没错误
          if (!err) {
            const permissionIds = []
            _this.permissions.forEach(permission => {
              permissionIds.push.apply(permissionIds, permission.selected)
            })
            values.permissionIds = permissionIds

            _this.confirmLoading = true
            _this.save(values).then(() => {
              _this.$message.success('保存成功')
              _this.$emit('ok')
              _this.close()
            }).catch((res) => {
              _this.$message.error(res.message || '保存失败')
            }).finally(() => {
              _this.confirmLoading = false
            })
          }
        })
      },
      handleCancel () {
        this.close()
      },
      onChangeCheck (permission) {
        permission.indeterminate = !!permission.selected.length && (permission.selected.length < permission.actionsOptions.length)
        permission.checkedAll = permission.selected.length === permission.actionsOptions.length
      },
      onChangeCheckAll (e, permission) {
        Object.assign(permission, {
          selected: e.target.checked ? permission.actionsOptions.map(obj => obj.value) : [],
          indeterminate: false,
          checkedAll: e.target.checked
        })
      },
      loadPermissions () {
        getPermissions().then(res => {
          const result = res.result
          this.permissions = result.map(permission => {
            permission.children.unshift({name: '可见', permission_id: permission.permission_id})
            return {
              id: permission.permission_id,
              name: permission.name,
              checkedAll: false,
              selected: [],
              indeterminate: false,
              actionsOptions : permission.children.map(child => {
                return {
                  label: child.name,
                  value: child.permission_id
                }
              })
            }
          })
        })
      }

    }
  }
</script>

<style scoped>

</style>