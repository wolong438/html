<template>
  <a-card :bordered="false">
    <div class="table-page-search-wrapper">
      <a-form layout="inline" :form="form">
        <a-row :gutter="48">
          <a-col :md="24" :sm="24">
            <span class="table-page-search-submitButtons">
              <a-button style="margin-left: 8px" @click="handleAdd()">新增</a-button>
            </span>
          </a-col>
        </a-row>
      </a-form>
    </div>
    <a-table
      ref="table"
      :columns="columns" 
      :dataSource="data" 
      :pagination="pagination" 
      :rowKey="rowKey"
    >
      <span slot="status" slot-scope="text">
        {{ text | statusFilter }}
      </span>

      <span slot="type" slot-scope="text">
        {{ text | typeFilter }}
      </span>

      <span slot="action" slot-scope="text, record">
        <a @click="handleEdit(record)">编辑</a>
        <a-divider type="vertical" />
        <a-dropdown>
          <a class="ant-dropdown-link">
            更多 <a-icon type="down" />
          </a>
          <a-menu slot="overlay">
            <a-menu-item>
              <a href="javascript:;">详情</a>
            </a-menu-item>
            <a-menu-item>
              <a href="javascript:;" @click="handleLock(record, 1)" v-show="record.status == 0">启用</a>
              <a href="javascript:;" @click="handleLock(record, 0)" v-show="record.status == 1">停用</a>
            </a-menu-item>
            <a-menu-item>
              <a href="javascript:;" @click="handleAdd(record.permission_id, record.type+1)">添加下级</a>
            </a-menu-item>
            <a-menu-item>
              <a href="javascript:;" @click="handleDelete(record)">删除</a>
            </a-menu-item>
          </a-menu>
        </a-dropdown>
      </span>
    </a-table>

    <permission-modal ref="modal" @ok="handleOk"></permission-modal>

  </a-card>
</template>

<script>

  import PermissionModal from './modules/PermissionModal'
  import {deletePermission, editPermission, getPermissionTree} from '@/api/auth'

  export default {
    name: 'PermissionList',
    components: {
      PermissionModal
    },
    data () {
      return {
        description: '',

        visible: false,
        labelCol: {
          xs: { span: 24 },
          sm: { span: 5 },
        },
        wrapperCol: {
          xs: { span: 24 },
          sm: { span: 16 },
        },
        form: this.$form.createForm(this),
        mdl: {},
        queryParam: {},
        columns: [
          {title: '权限名称', dataIndex: 'name'}, 
          {title: '类型', dataIndex: 'type', scopedSlots: { customRender: 'type' }},
          {title: '权限值', dataIndex: 'permission_value'},
          {title: '链接', dataIndex: 'uri'},
          {title: '状态', dataIndex: 'status', scopedSlots: { customRender: 'status' }},
          {title: '序列', dataIndex: 'orders', },
          {title: '操作', width: '150px', dataIndex: 'action', scopedSlots: { customRender: 'action' }}
        ],
        data: [],
        pagination: false,
        rowKey: 'permission_id'
      }
    },
    filters: {
      statusFilter(status) {
        const statusMap = {0: '停用', 1: '启用'}
        return statusMap[status]
      },
      typeFilter(type) {
        const typeMap = {1: '目录', 2: '菜单', 3: '按钮'}
        return typeMap[type]
      }
    },
    created () {
      this.getPermissions()
    },
    methods: {
      handleAdd (pid = 0, type = 1) {
        const record = {pid: pid, status: 0, type: type, orders: 1}
        if (type > 3) {
          this.$message.error('按钮不能添加下级权限')
          return
        }
        this.$refs.modal.edit(record)
      },
      handleEdit (record) {
        this.$refs.modal.edit(record)
      },
      handleLock (record, status) {
        const _this = this
        const parameter = {
          permission_id: record.permission_id,
          name: record.name,
          status: status + ''
        }
        editPermission(parameter).then(res => {
          if (res.status == 200) {
            _this.$message.success('操作成功')
            record.status = status
          } else {
            _this.$message.error(res.message || '操作失败')
          }
        }).catch(error => {
          console.log(error)
        })
      },
      handleDelete (record) {
        const _this = this
        const id = record.permission_id
        deletePermission(id).then(res => {
          if (res.status == 200) {
            _this.$message.success('操作成功')
            _this.handleOk()
          } else {
            _this.$message.error(res.message || '保存失败')
          }
        })
      },
      handleOk () {
        // 新增/修改 成功时，重载列表
        this.getPermissions()
      },
      onChange (selectedRowKeys, selectedRows) {
        this.selectedRowKeys = selectedRowKeys
        this.selectedRows = selectedRows
      },
      toggleAdvanced () {
        this.advanced = !this.advanced
      },
      getPermissions () {
        getPermissionTree().then(data => {
          console.log(data)
          this.data = data
        }).catch(error => {
          console.log(error)
        })
      }
    }
  }
</script>