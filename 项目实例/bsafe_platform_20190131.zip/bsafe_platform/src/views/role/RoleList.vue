<template>
  <a-card :bordered="false">
    <div class="table-page-search-wrapper">
      <a-form layout="inline" @submit="handleQuery" :form="form">
        <a-row :gutter="48">
          <a-col :md="8" :sm="24">
            <a-form-item label="标识">
              <a-input placeholder="请输入" v-model="queryParam.name"/>
            </a-form-item>
          </a-col>
          <a-col :md="8" :sm="24">
            <a-form-item label="名字">
              <a-input placeholder="请输入" v-model="queryParam.title"/>
            </a-form-item>
          </a-col>
          <a-col :md="8" :sm="24">
            <span class="table-page-search-submitButtons">
              <a-button type="primary" htmlType='submit'>查询</a-button>
              <a-button style="margin-left: 8px" @click="handleReset">重置</a-button>
              <a-button style="margin-left: 8px" @click="handleAdd">新增</a-button>
            </span>
          </a-col>
        </a-row>
      </a-form>
    </div>

    <s-table
      ref="table"
      size="default"
      :columns="columns"
      :data="loadData"
    >
      <div
        slot="expandedRowRender"
        slot-scope="record"
        style="margin: 0">
        <a-row
          :gutter="24"
          :style="{ marginBottom: '12px' }">
          <a-col :span="12" v-for="(permission, index) in record.permissions" :key="index" :style="{ marginBottom: '12px' }">
            <a-col :lg="6" :md="24">
              <span>{{ permission.name }}：</span>
            </a-col>
            <a-col :lg="18" :md="24" v-if="permission.children.length > 0">
              <a-tag color="cyan" v-for="(action, k) in permission.children" :key="k">{{ action.name }}</a-tag>
            </a-col>
            <a-col :span="20" v-else>-</a-col>
          </a-col>
        </a-row>
      </div>

      <span slot="ctime" slot-scope="text">
        {{ text | timestampFilter }}
      </span>

      <span slot="action" slot-scope="text, record">
        <a @click="handleEdit(record)">编辑</a>
        <a-divider type="vertical" />
        <a-dropdown>
          <a class="ant-dropdown-link">
            更多 <a-icon type="down" />
          </a>
          <a-menu slot="overlay">
            <a-menu-item>
              <a href="javascript:;">详情</a>
            </a-menu-item>
            <a-menu-item>
              <a href="javascript:;" @click="handleLock(record, 1)" v-show="record.locked == 0">禁用</a>
              <a href="javascript:;" @click="handleLock(record, 0)" v-show="record.locked == 1">启用</a>
            </a-menu-item>
            <a-menu-item>
              <a href="javascript:;" @click="handleDelete(record)">删除</a>
            </a-menu-item>
          </a-menu>
        </a-dropdown>
      </span>
    </s-table>

    <role-modal ref="modal" @ok="handleOk"></role-modal>

  </a-card>
</template>

<script>
  import STable from '@/components/table/'
  import RoleModal from './modules/RoleModal'
  import {getRoleList, deleteRole} from '@/api/auth'
  import {pageDataAdapter, pageParamsAdapter, formatDate} from '@/utils/util'

  export default {
    name: 'RoleList',
    components: {
      STable,
      RoleModal
    },
    data () {
      return {
        description: '列表使用场景：后台管理中的权限管理以及角色管理，可用于基于 RBAC 设计的角色权限控制，颗粒度细到每一个操作类型。',

        form: this.$form.createForm(this),

        // 高级搜索 展开/关闭
        advanced: false,
        // 查询参数
        queryParam: {
          name: '',
          title: '',
          jumpTo: 0
        },
        // 表头
        columns: [
          {
            title: '标识',
            dataIndex: 'name'
          },
          {
            title: '名字',
            dataIndex: 'title'
          },
          {
            title: '描述',
            dataIndex: 'description',
          },
          {
            title: '序号',
            dataIndex: 'orders',
          },
          {
            title: '创建时间',
            dataIndex: 'ctime',
            sorter: true,
            scopedSlots: { customRender: 'ctime' }
          }, {
            title: '操作',
            width: '150px',
            dataIndex: 'action',
            scopedSlots: { customRender: 'action' },
          }
        ],
        // 加载数据方法 必须为 Promise 对象
        loadData: parameter => {
          const params = Object.assign(pageParamsAdapter(parameter), this.queryParam)
          if (params.jumpTo > 0) {
            params.pageNow = params.jumpTo
            this.queryParam.jumpTo = 0
          }
          return getRoleList(params)
            .then(res => {console.log(res)
              return pageDataAdapter(res.result)
            })
        },
        selectedRowKeys: [],
        selectedRows: []
      }
    },
    filters: {
      timestampFilter(timestamp) {
        const date = new Date(timestamp)
        return formatDate(date)
      }
    },
    methods: {
      handleQuery (e) {
        e.preventDefault()
        Object.assign(this.queryParam, this.form.getFieldsValue(), {jumpTo: 1})
        this.handleOk()
      },
      handleReset () {
        this.form.resetFields()
        this.queryParam = {username: '', locked: ''}
      },
      handleAdd () {
        this.$refs.modal.add()
      },
      handleEdit (record) {
        this.$refs.modal.edit(record)
      },
      handleDelete (record) {
        const _this = this
        const id = record.user_id
        deleteRole(id).then(res => {
          if (res.status == 200) {
            _this.$message.success(res.message)
            _this.handleOk()
          } else {
            _this.$message.error(res.message || '保存失败')
          }
        })
      },
      handleOk () {
        // 新增/修改 成功时，重载列表
        this.$refs.table.refresh()
      },
      onChange (selectedRowKeys, selectedRows) {
        this.selectedRowKeys = selectedRowKeys
        this.selectedRows = selectedRows
      },
      toggleAdvanced () {
        this.advanced = !this.advanced
      }
    },
    watch: {
      /*
      'selectedRows': function (selectedRows) {
        this.needTotalList = this.needTotalList.map(item => {
          return {
            ...item,
            total: selectedRows.reduce( (sum, val) => {
              return sum + val[item.dataIndex]
            }, 0)
          }
        })
      }
      */
    }
  }
</script>