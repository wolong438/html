<template>
  <a-card :bordered="false">
    <div class="table-page-search-wrapper">
      <a-form layout="inline" @submit="handleQuery" :form="form">
        <a-row :gutter="48">
          <a-col :md="8" :sm="24">
            <a-form-item label="账号">
              <a-input placeholder="请输入" v-model="queryParam.username"/>
            </a-form-item>
          </a-col>
          <a-col :md="8" :sm="24">
            <a-form-item label="状态">
              <a-select placeholder="请选择" defaultValue="" v-model="queryParam.locked">
                <a-select-option value="">全部</a-select-option>
                <a-select-option value="0">启用</a-select-option>
                <a-select-option value="1">停用</a-select-option>
              </a-select>
            </a-form-item>
          </a-col>
          <a-col :md="8" :sm="24">
            <span class="table-page-search-submitButtons">
              <a-button type="primary" htmlType='submit'>查询</a-button>
              <a-button style="margin-left: 8px" @click="handleReset">重置</a-button>
              <a-button style="margin-left: 8px" @click="handleAdd">新增</a-button>
            </span>
          </a-col>
        </a-row>
      </a-form>
    </div>

    <s-table
      ref="table"
      size="default"
      :columns="columns"
      :data="loadData"
    >
      <div
        slot="expandedRowRender"
        slot-scope="record"
        style="margin: 0">
        <a-row
          :gutter="24"
          :style="{ marginBottom: '12px' }">
          <a-col :span="12" v-for="(permission, index) in record.permissions" :key="index" :style="{ marginBottom: '12px' }">
            <a-col :lg="6" :md="24">
              <span>{{ permission.name }}：</span>
            </a-col>
            <a-col :lg="18" :md="24" v-if="permission.children.length > 0">
              <a-tag color="cyan" v-for="(action, k) in permission.children" :key="k">{{ action.name }}</a-tag>
            </a-col>
            <a-col :span="20" v-else>-</a-col>
          </a-col>
        </a-row>
      </div>

      <span slot="locked" slot-scope="text">
        {{ text | statusFilter }}
      </span>
      <span slot="ctime" slot-scope="text">
        {{ text | timestampFilter }}
      </span>

      <span slot="action" slot-scope="text, record">
        <a @click="handleEdit(record)">编辑</a>
        <a-divider type="vertical" />
        <a-dropdown>
          <a class="ant-dropdown-link">
            更多 <a-icon type="down" />
          </a>
          <a-menu slot="overlay">
            <a-menu-item>
              <a href="javascript:;">详情</a>
            </a-menu-item>
            <a-menu-item>
              <a href="javascript:;" @click="handleLock(record, 1)" v-show="record.locked == 0">禁用</a>
              <a href="javascript:;" @click="handleLock(record, 0)" v-show="record.locked == 1">启用</a>
            </a-menu-item>
            <a-menu-item>
              <a href="javascript:;" @click="handleDelete(record)">删除</a>
            </a-menu-item>
          </a-menu>
        </a-dropdown>
      </span>
    </s-table>

    <user-modal ref="modal" @ok="handleOk"></user-modal>

  </a-card>
</template>

<script>
  import STable from '@/components/table/'
  import UserModal from './modules/UserModal'
  import {getUserList, deleteUser, editUser} from '@/api/auth'
  import {pageDataAdapter, pageParamsAdapter, formatDate} from '@/utils/util'

  export default {
    name: 'TableList',
    components: {
      STable,
      UserModal
    },
    data () {
      return {
        description: '列表使用场景：后台管理中的权限管理以及角色管理，可用于基于 RBAC 设计的角色权限控制，颗粒度细到每一个操作类型。',

        form: this.$form.createForm(this),

        // 高级搜索 展开/关闭
        advanced: false,
        // 查询参数
        queryParam: {
          username: '',
          locked: '',
          jumpTo: 0
        },
        // 表头
        columns: [
          {
            title: '账号',
            dataIndex: 'username'
          },
          {
            title: '昵称',
            dataIndex: 'realname',
          },
          {
            title: '角色',
            dataIndex: 'roles',
          },
          {
            title: '状态',
            dataIndex: 'locked',
            scopedSlots: { customRender: 'locked' }
          },
          {
            title: '创建时间',
            dataIndex: 'ctime',
            sorter: true,
            scopedSlots: { customRender: 'ctime' }
          }, {
            title: '操作',
            width: '150px',
            dataIndex: 'action',
            scopedSlots: { customRender: 'action' },
          }
        ],
        // 加载数据方法 必须为 Promise 对象
        loadData: parameter => {
          const params = Object.assign(pageParamsAdapter(parameter), this.queryParam)
          if (params.jumpTo > 0) {
            params.pageNow = params.jumpTo
            this.queryParam.jumpTo = 0
          }
          return getUserList(params)
            .then(res => {console.log(res)
              return pageDataAdapter(res.result)
            })
        },
        selectedRowKeys: [],
        selectedRows: []
      }
    },
    filters: {
      statusFilter(status) {
        const statusMap = {
          0: '启用',
          1: '停用'
        }
        return statusMap[status]
      },
      timestampFilter(timestamp) {
        const date = new Date(timestamp)
        return formatDate(date)
      }
    },
    methods: {
      handleQuery (e) {
        e.preventDefault()
        Object.assign(this.queryParam, this.form.getFieldsValue(), {jumpTo: 1})
        this.$refs.table.refresh()
      },
      handleReset () {
        this.form.resetFields()
        this.queryParam = {username: '', locked: ''}
      },
      handleAdd () {
        this.$refs.modal.add()
      },
      handleEdit (record) {
        this.$refs.modal.edit(record)
      },
      handleLock (record, locked) {
        const _this = this
        const parameter = {
          username: record.username,
          locked: locked + ''
        }
        editUser(parameter).then(res => {
          if (res.status == 200) {
            _this.$message.success('操作成功')
            record.locked = locked
          } else {
            _this.$message.error('操作失败')
          }
        }).catch(error => {
          console.log(error)
        })
      },
      handleDelete (record) {
        const _this = this
        const id = record.user_id
        deleteUser(id).then(res => {
          if (res.status == 200) {
            _this.$message.success(res.message)
            _this.$refs.table.refresh()
          } else {
            _this.$message.error(res.message || '保存失败')
          }
        })
      },
      handleOk () {
        // 新增/修改 成功时，重载列表
        this.$refs.table.refresh()
      },
      onChange (selectedRowKeys, selectedRows) {
        this.selectedRowKeys = selectedRowKeys
        this.selectedRows = selectedRows
      },
      toggleAdvanced () {
        this.advanced = !this.advanced
      }
    },
    watch: {
      /*
      'selectedRows': function (selectedRows) {
        this.needTotalList = this.needTotalList.map(item => {
          return {
            ...item,
            total: selectedRows.reduce( (sum, val) => {
              return sum + val[item.dataIndex]
            }, 0)
          }
        })
      }
      */
    }
  }
</script>