export function timeFix() {
  const time = new Date()
  const hour = time.getHours()
  return hour < 9 ? '早上好' : (hour <= 11 ? '上午好' : (hour <= 13 ? '中午好' : (hour < 20 ? '下午好' : '晚上好')))
}

export function welcome() {
  const arr = ['休息一会儿吧', '准备吃什么呢?', '要不要打一把 DOTA', '我猜你可能累了']
  const index = Math.floor((Math.random()*arr.length))
  return arr[index]
}

/**
 * 触发 window.resize
 */
export function triggerWindowResizeEvent() {
  const event = document.createEvent('HTMLEvents')
  event.initEvent('resize', true, true)
  event.eventType = 'message'
  window.dispatchEvent(event)
}

/**
 * Remove loading animate
 * @param id parent element id or class
 * @param timeout
 */
export function removeLoadingAnimate(id = '', timeout = 1500) {
  if (id === '') {
    return
  }
  setTimeout(() => {
    document.getElementById(id).remove()
  }, timeout)
}

/**
 * 分页数据转化
 * @param { ,pageCount, pageSize, pageNow, rowCount, records} result 
 */
export function pageDataAdapter(result) {
  return {
    data: result.records,
    pageSize: result.pageSize,
    pageNo: result.pageNow,
    totalPage: result.pageCount,
    totalCount: result.rowCount
  }
}

/**
 * 分页查询参数转化
 * @param {*} paramter 
 */
export function pageParamsAdapter(paramter) {
  const params = Object.assign({}, paramter)
  if (!params.pageSize) params.pageSize = 10
  if (!params.pageNo) params.pageNo = 1
  if (!params.pageNow) {
    params.pageNow = params.pageNo
    delete params.pageNo
  }
  return params
}


/**
 * 时间格式化
 * @param {Date} date 
 * @param {,yyyy-MM-dd hh:mm:ss} fmt 
 */
export function formatDate (date, fmt) {
  const padLeftZero = (str) => ('00' + str).substr(str.length)

  if (!fmt || typeof fmt != 'string') {
    fmt = 'yyyy-MM-dd hh:mm:ss'
  }
  if (/(y+)/.test(fmt)) {
    fmt = fmt.replace(RegExp.$1, (date.getFullYear() + '').substr(4 - RegExp.$1.length))
  }
  const o = {
    'M+': date.getMonth() + 1,
    'd+': date.getDate(),
    'h+': date.getHours(),
    'm+': date.getMinutes(),
    's+': date.getSeconds()
  }
  for (const k in o) {
    if (new RegExp(`(${k})`).test(fmt)) {
      const str = o[k] + ''
      fmt = fmt.replace(RegExp.$1, RegExp.$1.length === 1 ? str : padLeftZero(str))
    }
  }
  return fmt
}